import { Star } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useNavigate } from "react-router-dom";

interface AgentCardProps {
  id: string;
  name: string;
  expertise: string;
  rating: number;
  bio: string;
  avatar: string;
  isOnline?: boolean;
  isFeatured?: boolean;
}

export const AgentCard = ({
  id,
  name,
  expertise,
  rating,
  avatar,
  bio,
  isOnline = true,
  isFeatured = false,
}: AgentCardProps) => {
  const navigate = useNavigate();

  return (
    <Card
      onClick={() => navigate(`/chat/${id}`)}
      className={`
        glass p-5 rounded-3xl cursor-pointer 
        transition-all duration-300 hover:scale-[1.02] hover:shadow-xl
        animate-fade-in flex flex-col items-center text-center
        aspect-square
        ${isFeatured ? "border-2 border-primary/30" : ""}
      `}
    >
      <div className="relative mb-3">
        <Avatar className="h-20 w-20 ring-2 ring-white/50">
          <AvatarImage src={avatar} alt={name} />
          <AvatarFallback>{name.split(" ").map(n => n[0]).join("")}</AvatarFallback>
        </Avatar>
        {isOnline && (
          <div className="absolute bottom-0 right-0 h-4 w-4 bg-success rounded-full border-2 border-white" />
        )}
      </div>

      <div className="flex items-center gap-1 bg-amber-50 dark:bg-amber-950 px-2 py-1 rounded-full mb-2">
        <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
        <span className="text-sm font-medium text-amber-700 dark:text-amber-300">{rating}</span>
      </div>

      <h3 className="font-semibold text-lg text-foreground mb-1">{name}</h3>
      <p className="text-xs text-muted-foreground mb-2">{expertise}</p>
      <p className="text-xs text-foreground/70 line-clamp-3">{bio}</p>
    </Card>
  );
};
