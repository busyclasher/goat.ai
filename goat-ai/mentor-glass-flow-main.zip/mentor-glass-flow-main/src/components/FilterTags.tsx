import { useState } from "react";
import { Badge } from "@/components/ui/badge";

const tags = ["Business", "Tech", "Career", "Life", "Health"];

export const FilterTags = () => {
  const [activeTag, setActiveTag] = useState<string | null>(null);

  return (
    <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
      {tags.map((tag) => (
        <Badge
          key={tag}
          variant={activeTag === tag ? "default" : "secondary"}
          className={`
            cursor-pointer whitespace-nowrap px-4 py-2 text-sm rounded-full
            transition-all duration-200 hover:scale-105
            ${activeTag === tag 
              ? "bg-primary text-primary-foreground shadow-md" 
              : "glass hover:glass-dark"
            }
          `}
          onClick={() => setActiveTag(activeTag === tag ? null : tag)}
        >
          {tag}
        </Badge>
      ))}
    </div>
  );
};
