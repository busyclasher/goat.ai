import { useEffect, useRef, useState } from "react";
import { Phone, PhoneOff } from "lucide-react";
import { cn } from "@/lib/utils";

interface VoiceInterfaceProps {
  onClose: () => void;
  agentName?: string;
}

export const VoiceInterface = ({ onClose, agentName }: VoiceInterfaceProps) => {
  const [isListening, setIsListening] = useState(true);
  const [audioLevels, setAudioLevels] = useState<number[]>(Array(40).fill(0));
  const animationFrameRef = useRef<number>();

  useEffect(() => {
    // Simulate audio levels for visualization
    const animate = () => {
      setAudioLevels(prev => 
        prev.map(() => Math.random() * (isListening ? 0.8 : 0.2))
      );
      animationFrameRef.current = requestAnimationFrame(animate);
    };
    
    animate();
    
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isListening]);

  return (
    <div className="px-6 py-12 border-t border-white/10 glass-vibrant sticky bottom-0">
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-col items-center justify-center gap-6">
          {/* Main orb with orbiting dot */}
          <div className="relative w-32 h-32 flex items-center justify-center flex-shrink-0">
            {/* Large iridescent orb */}
            <div className={cn(
              "w-28 h-28 rounded-full bg-gradient-to-br from-purple-500 via-blue-500 to-teal-400 transition-all duration-300",
              isListening && "shadow-lg shadow-purple-500/40"
            )} />
          </div>

          {/* Status and audio levels below orb */}
          <div className="flex flex-col items-center gap-3">
            <p className="text-sm font-medium text-foreground">
              {isListening ? "Listening" : "Paused"}
            </p>
            
            {/* Audio level indicators */}
            <div className="flex items-center gap-1">
              {audioLevels.slice(0, 5).map((level, i) => (
                <div
                  key={i}
                  className="w-2 bg-foreground/80 rounded-full transition-all duration-100"
                  style={{
                    height: `${Math.max(8, level * 24)}px`,
                    opacity: isListening ? 1 : 0.3
                  }}
                />
              ))}
            </div>
          </div>

          {/* Control Buttons below */}
          <div className="flex items-center gap-3 justify-center">
            {/* Pause button */}
            <button
              onClick={() => setIsListening(!isListening)}
              className="h-14 w-14 rounded-full bg-muted hover:bg-muted/80 text-foreground transition-all duration-300 hover:scale-105 flex items-center justify-center"
            >
              {isListening ? (
                <div className="flex gap-1">
                  <div className="w-1 h-6 bg-foreground rounded-full" />
                  <div className="w-1 h-6 bg-foreground rounded-full" />
                </div>
              ) : (
                <Phone className="h-5 w-5" />
              )}
            </button>

            {/* Close button */}
            <button
              onClick={onClose}
              className="h-14 w-14 rounded-full bg-red-500 hover:bg-red-600 text-white transition-all duration-300 hover:scale-105 flex items-center justify-center"
            >
              <PhoneOff className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
