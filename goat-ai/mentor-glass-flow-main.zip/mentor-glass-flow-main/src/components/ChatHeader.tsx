import { Menu } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";

interface ChatHeaderProps {
  name: string;
  avatar: string;
  isOnline?: boolean;
}

export const ChatHeader = ({ name, avatar, isOnline = true }: ChatHeaderProps) => {
  return (
    <div className="glass-vibrant border-b border-white/10 px-4 py-3.5 flex items-center gap-3 sticky top-0 z-10 shadow-sm">
      <Avatar className="h-11 w-11 ring-2 ring-primary/20 shadow-md">
        <AvatarImage src={avatar} alt={name} />
        <AvatarFallback>{name.split(" ").map(n => n[0]).join("")}</AvatarFallback>
      </Avatar>

      <div className="flex-1 min-w-0">
        <h2 className="font-semibold text-foreground">{name}</h2>
        {isOnline && (
          <div className="flex items-center gap-1.5 text-xs text-success">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-success opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-success"></span>
            </span>
            Online
          </div>
        )}
      </div>

      <Button variant="ghost" size="icon" className="rounded-full hover:bg-white/50 transition-all duration-300">
        <Menu className="h-5 w-5" />
      </Button>
    </div>
  );
};
