import { useState } from "react";
import { Send, Sparkles, Phone } from "lucide-react";
import { Input } from "@/components/ui/input";
import { VoiceInterface } from "./VoiceInterface";

interface ChatInputProps {
  onSend: (message: string) => void;
  agentName?: string;
}

export const ChatInput = ({ onSend, agentName }: ChatInputProps) => {
  const [message, setMessage] = useState("");
  const [isVoiceMode, setIsVoiceMode] = useState(false);

  const handleSend = () => {
    if (message.trim()) {
      onSend(message);
      setMessage("");
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleSend();
    }
  };

  if (isVoiceMode) {
    return <VoiceInterface onClose={() => setIsVoiceMode(false)} agentName={agentName} />;
  }

  return (
    <div className="px-4 py-4 border-t border-white/10 glass-vibrant sticky bottom-0">
      <div className="max-w-2xl mx-auto flex gap-3 items-center">
        <div className="relative flex-1">
          <Sparkles className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={`Ask ${agentName || "a question"}...`}
            className="pl-11 h-12 rounded-full glass border-white/20 focus-visible:ring-2 focus-visible:ring-primary/50 transition-all duration-300"
          />
        </div>
        <button
          onClick={handleSend}
          disabled={!message.trim()}
          className="h-12 w-12 rounded-full shrink-0 bg-primary text-primary-foreground transition-all duration-300 hover:scale-105 soft-glow disabled:opacity-50 disabled:hover:scale-100 flex items-center justify-center"
        >
          <Send className="h-5 w-5" />
        </button>
        <button
          onClick={() => setIsVoiceMode(true)}
          className="h-12 w-12 rounded-full shrink-0 glass text-foreground transition-all duration-300 hover:scale-105 hover:shadow-lg flex items-center justify-center"
        >
          <Phone className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
};
