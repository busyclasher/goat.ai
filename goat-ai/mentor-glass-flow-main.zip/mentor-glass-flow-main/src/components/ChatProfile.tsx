import { Sparkles } from "lucide-react";

interface ChatProfileProps {
  name: string;
  expertise: string;
  bio: string;
  avatar: string;
  onStartChat: (question: string) => void;
}

const suggestedQuestions = [
  "Help me figure out where my money goes each month",
  "I have savings but don't know how to invest it properly",
  "Trying to decide if I should rent or buy in this market",
];

export const ChatProfile = ({ name, expertise, bio, avatar, onStartChat }: ChatProfileProps) => {
  return (
    <div className="flex flex-col items-center px-6 py-8 space-y-6 animate-fade-in">
      {/* Profile Header */}
      <div className="relative">
        <div className="absolute inset-0 bg-primary/10 rounded-full blur-3xl" />
        <img
          src={avatar}
          alt={name}
          className="relative w-32 h-32 rounded-full object-cover ring-4 ring-white/60 shadow-xl"
        />
      </div>

      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-gradient">{name}</h1>
        <p className="text-muted-foreground font-medium">{expertise}</p>
        <p className="text-sm text-foreground/70 max-w-md leading-relaxed">{bio}</p>
      </div>

      {/* Suggested Questions */}
      <div className="w-full max-w-2xl space-y-3 pt-6">
        <h2 className="text-lg font-semibold text-foreground">Suggested Questions</h2>
        {suggestedQuestions.map((question, index) => (
          <div
            key={index}
            onClick={() => onStartChat(question)}
            className="glass p-4 rounded-2xl cursor-pointer transition-all duration-300 hover:scale-[1.02] hover:shadow-lg animate-slide-up"
            style={{ animationDelay: `${index * 0.1}s` }}
          >
            <div className="flex items-center gap-3">
              <Sparkles className="h-4 w-4 text-primary shrink-0" />
              <p className="text-sm text-foreground font-medium">{question}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
