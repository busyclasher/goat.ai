import { cn } from "@/lib/utils";

interface ChatMessageProps {
  content: string;
  isUser: boolean;
  timestamp?: string;
}

export const ChatMessage = ({ content, isUser, timestamp }: ChatMessageProps) => {
  return (
    <div className={cn("flex w-full mb-4 animate-slide-up", isUser ? "justify-end" : "justify-start")}>
      <div
        className={cn(
          "max-w-[80%] px-5 py-3.5 rounded-3xl shadow-lg transition-all duration-300",
          isUser
            ? "bg-primary text-primary-foreground ml-auto rounded-br-md soft-glow"
            : "glass text-foreground rounded-bl-md"
        )}
      >
        <p className="text-sm leading-relaxed">{content}</p>
        {timestamp && (
          <p className={cn("text-xs mt-1.5", isUser ? "opacity-80" : "opacity-60")}>{timestamp}</p>
        )}
      </div>
    </div>
  );
};
