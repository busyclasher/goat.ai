import { useState, useRef, useEffect } from "react";
import { ChatMessage } from "@/components/ChatMessage";
import { ChatInput } from "@/components/ChatInput";
import { ChatProfile } from "@/components/ChatProfile";
import sherryJiang from "@/assets/sherry-new.png";

const agent = {
  name: "Sherry Jiang",
  avatar: sherryJiang,
  expertise: "Product Strategy • Startup Growth",
  bio: "Building Peek: peek.money | codewithai.xyz | Cursor Ambassador | ex-Google | Berkeley Haas",
};

interface Message {
  id: string;
  content: string;
  isUser: boolean;
  timestamp: string;
}

const Chat = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [hasStartedChat, setHasStartedChat] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (messages.length > 0) {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const handleSendMessage = (content: string) => {
    if (!hasStartedChat) {
      setHasStartedChat(true);
    }

    const newMessage: Message = {
      id: Date.now().toString(),
      content,
      isUser: true,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };
    setMessages([...messages, newMessage]);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: "That's a great question! Let me share my perspective based on my experience. When it comes to product strategy, the key is...",
        isUser: false,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };
      setMessages((prev) => [...prev, aiResponse]);
    }, 1000);
  };

  return (
    <div className="flex flex-col h-screen">
      <div className="flex-1 overflow-y-auto">
        <ChatProfile
          name={agent.name}
          expertise={agent.expertise}
          bio={agent.bio}
          avatar={agent.avatar}
          onStartChat={handleSendMessage}
        />
        
        {messages.length > 0 && (
          <div className="px-4 py-6">
            <div className="max-w-2xl mx-auto">
              {messages.map((message) => (
                <ChatMessage
                  key={message.id}
                  content={message.content}
                  isUser={message.isUser}
                  timestamp={message.timestamp}
                />
              ))}
              <div ref={messagesEndRef} />
            </div>
          </div>
        )}
      </div>

      <ChatInput onSend={handleSendMessage} agentName={agent.name} />
    </div>
  );
};

export default Chat;
