import { SearchBar } from "@/components/SearchBar";
import { FilterTags } from "@/components/FilterTags";
import { AgentCard } from "@/components/AgentCard";
import sherryJiang from "@/assets/sherry-jiang.jpg";
import mentor2 from "@/assets/mentor-2.jpg";
import mentor3 from "@/assets/mentor-3.jpg";

const agents = [
  {
    id: "sherry-jiang",
    name: "Sherry Jiang",
    expertise: "Product Strategy • Startup Growth",
    rating: 4.9,
    bio: "Former VP at Meta, scaled products 0→100M users",
    avatar: sherryJiang,
    isOnline: true,
    isFeatured: true,
  },
  {
    id: "james-chen",
    name: "James Chen",
    expertise: "Engineering • System Design",
    rating: 4.8,
    bio: "Ex-Google Staff Engineer, built infrastructure serving 1B+ requests/day",
    avatar: mentor2,
    isOnline: true,
  },
  {
    id: "maya-patel",
    name: "Maya Patel",
    expertise: "Career Growth • Leadership",
    rating: 4.9,
    bio: "Former McKinsey Partner, helped 100+ executives advance their careers",
    avatar: mentor3,
    isOnline: false,
  },
];

const Home = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Header with safe area */}
      <div className="sticky top-0 z-10 glass border-b border-white/20 px-4 pt-6 pb-4 space-y-4">
        <div>
          <h1 className="text-2xl font-bold text-gradient mb-1">AI Mentors</h1>
          <p className="text-sm text-muted-foreground">Find expert guidance for your journey</p>
        </div>
        <SearchBar />
        <FilterTags />
      </div>

      {/* Agent Cards Grid */}
      <div className="px-4 py-6 max-w-4xl mx-auto">
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3">
          {agents.map((agent) => (
            <AgentCard key={agent.id} {...agent} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Home;
